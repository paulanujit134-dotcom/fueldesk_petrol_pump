import os, sqlite3
from datetime import datetime, date
from functools import wraps
from flask import Flask, g, render_template, request, redirect, url_for, flash, session
app=Flask(__name__); app.secret_key=os.environ.get("SECRET_KEY","change-this-secret")
DB=os.environ.get("DATABASE_PATH","petrol_pump.db")
def db():
    if "db" not in g:
        g.db=sqlite3.connect(DB); g.db.row_factory=sqlite3.Row; g.db.execute("PRAGMA foreign_keys=ON")
    return g.db
@app.teardown_appcontext
def close_db(e):
    c=g.pop("db",None)
    if c: c.close()
def init_db():
    c=sqlite3.connect(DB)
    c.executescript("""
    CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY,username TEXT UNIQUE,password TEXT);
    CREATE TABLE IF NOT EXISTS fuels(id INTEGER PRIMARY KEY,name TEXT UNIQUE,price REAL NOT NULL,stock REAL NOT NULL DEFAULT 0);
    CREATE TABLE IF NOT EXISTS sales(id INTEGER PRIMARY KEY,created_at TEXT,fuel_id INTEGER,litres REAL,rate REAL,amount REAL,payment_mode TEXT,customer TEXT,FOREIGN KEY(fuel_id) REFERENCES fuels(id));
    CREATE TABLE IF NOT EXISTS readings(id INTEGER PRIMARY KEY,created_at TEXT,nozzle TEXT,fuel_id INTEGER,opening REAL,closing REAL,litres REAL,rate REAL,amount REAL,FOREIGN KEY(fuel_id) REFERENCES fuels(id));
    CREATE TABLE IF NOT EXISTS expenses(id INTEGER PRIMARY KEY,created_at TEXT,category TEXT,amount REAL,note TEXT);
    CREATE TABLE IF NOT EXISTS customers(id INTEGER PRIMARY KEY,name TEXT,phone TEXT,balance REAL DEFAULT 0);
    """)
    if not c.execute("SELECT 1 FROM users").fetchone(): c.execute("INSERT INTO users(username,password) VALUES('admin','ChangeMe123!')")
    if not c.execute("SELECT 1 FROM fuels").fetchone(): c.executemany("INSERT INTO fuels(name,price,stock) VALUES(?,?,?)",[("Petrol",100,5000),("Diesel",90,5000)])
    c.commit(); c.close()
def auth(f):
    @wraps(f)
    def w(*a,**k):
        if not session.get("user"): return redirect(url_for("login"))
        return f(*a,**k)
    return w
@app.route("/login",methods=["GET","POST"])
def login():
    if request.method=="POST":
        u=request.form.get("username",""); p=request.form.get("password","")
        if db().execute("SELECT 1 FROM users WHERE username=? AND password=?",(u,p)).fetchone():
            session["user"]=u; return redirect(url_for("home"))
        flash("Incorrect username or password.","danger")
    return render_template("login.html")
@app.route("/logout")
def logout(): session.clear(); return redirect(url_for("login"))
@app.route("/")
@auth
def home():
    c=db(); today=date.today().isoformat()
    total=c.execute("SELECT COALESCE(SUM(amount),0) v FROM sales WHERE date(created_at)=?",(today,)).fetchone()["v"]
    litres=c.execute("SELECT COALESCE(SUM(litres),0) v FROM sales WHERE date(created_at)=?",(today,)).fetchone()["v"]
    exp=c.execute("SELECT COALESCE(SUM(amount),0) v FROM expenses WHERE date(created_at)=?",(today,)).fetchone()["v"]
    fuels=c.execute("SELECT * FROM fuels ORDER BY name").fetchall()
    sales=c.execute("SELECT s.*,f.name fuel FROM sales s JOIN fuels f ON f.id=s.fuel_id ORDER BY s.id DESC LIMIT 10").fetchall()
    return render_template("home.html",total=total,litres=litres,exp=exp,fuels=fuels,sales=sales)
@app.route("/fuels",methods=["GET","POST"])
@auth
def fuels_page():
    c=db()
    if request.method=="POST":
        try:
            c.execute("INSERT INTO fuels(name,price,stock) VALUES(?,?,?)",(request.form["name"].strip(),float(request.form["price"]),float(request.form["stock"])))
            c.commit(); flash("Fuel type added.","success")
        except Exception: c.rollback(); flash("Invalid details or fuel name already exists.","danger")
        return redirect(url_for("fuels_page"))
    return render_template("fuels.html",fuels=c.execute("SELECT * FROM fuels ORDER BY name").fetchall())
@app.route("/sale",methods=["GET","POST"])
@auth
def sale():
    c=db(); fuels=c.execute("SELECT * FROM fuels ORDER BY name").fetchall()
    if request.method=="POST":
        try:
            fid=int(request.form["fuel_id"]); qty=float(request.form["litres"]); mode=request.form["payment_mode"]
            f=c.execute("SELECT * FROM fuels WHERE id=?",(fid,)).fetchone()
            if not f or qty<=0 or qty>f["stock"] or mode not in ["Cash","UPI","Card","Credit"]: raise ValueError()
            amt=round(qty*f["price"],2)
            c.execute("INSERT INTO sales(created_at,fuel_id,litres,rate,amount,payment_mode,customer) VALUES(?,?,?,?,?,?,?)",(datetime.now().isoformat(timespec="seconds"),fid,qty,f["price"],amt,mode,request.form.get("customer","")))
            c.execute("UPDATE fuels SET stock=stock-? WHERE id=?",(qty,fid)); c.commit(); flash("Sale saved. Amount ₹%.2f"%amt,"success")
        except Exception: c.rollback(); flash("Sale not saved. Check fuel, quantity and available stock.","danger")
        return redirect(url_for("sale"))
    return render_template("sale.html",fuels=fuels)
@app.route("/readings",methods=["GET","POST"])
@auth
def readings():
    c=db(); fuels=c.execute("SELECT * FROM fuels").fetchall()
    if request.method=="POST":
        try:
            nozzle=request.form["nozzle"]; fid=int(request.form["fuel_id"]); op=float(request.form["opening"]); cl=float(request.form["closing"])
            f=c.execute("SELECT * FROM fuels WHERE id=?",(fid,)).fetchone(); qty=cl-op
            if not f or not nozzle or op<0 or qty<=0: raise ValueError()
            c.execute("INSERT INTO readings(created_at,nozzle,fuel_id,opening,closing,litres,rate,amount) VALUES(?,?,?,?,?,?,?,?)",(datetime.now().isoformat(timespec="seconds"),nozzle,fid,op,cl,qty,f["price"],round(qty*f["price"],2))); c.commit(); flash("Meter reading recorded.","success")
        except Exception: c.rollback(); flash("Closing reading must be greater than opening.","danger")
        return redirect(url_for("readings"))
    rows=c.execute("SELECT r.*,f.name fuel FROM readings r JOIN fuels f ON f.id=r.fuel_id ORDER BY r.id DESC LIMIT 40").fetchall()
    return render_template("readings.html",fuels=fuels,rows=rows)
@app.route("/expenses",methods=["GET","POST"])
@auth
def expenses():
    c=db()
    if request.method=="POST":
        try:
            amount=float(request.form["amount"])
            if amount<=0: raise ValueError()
            c.execute("INSERT INTO expenses(created_at,category,amount,note) VALUES(?,?,?,?)",(datetime.now().isoformat(timespec="seconds"),request.form["category"],amount,request.form.get("note",""))); c.commit(); flash("Expense saved.","success")
        except Exception: c.rollback(); flash("Enter valid expense details.","danger")
        return redirect(url_for("expenses"))
    return render_template("expenses.html",rows=c.execute("SELECT * FROM expenses ORDER BY id DESC LIMIT 50").fetchall())
@app.route("/customers",methods=["GET","POST"])
@auth
def customers():
    c=db()
    if request.method=="POST":
        try:
            c.execute("INSERT INTO customers(name,phone) VALUES(?,?)",(request.form["name"],request.form.get("phone",""))); c.commit(); flash("Customer added.","success")
        except Exception: c.rollback(); flash("Enter a customer name.","danger")
        return redirect(url_for("customers"))
    return render_template("customers.html",rows=c.execute("SELECT * FROM customers ORDER BY name").fetchall())
@app.route("/reports")
@auth
def reports():
    c=db(); start=request.args.get("start",date.today().isoformat()); end=request.args.get("end",date.today().isoformat())
    rows=c.execute("SELECT s.*,f.name fuel FROM sales s JOIN fuels f ON f.id=s.fuel_id WHERE date(s.created_at) BETWEEN ? AND ? ORDER BY s.id DESC",(start,end)).fetchall()
    totals=c.execute("SELECT COALESCE(SUM(amount),0) amount,COALESCE(SUM(litres),0) litres,COUNT(*) n FROM sales WHERE date(created_at) BETWEEN ? AND ?",(start,end)).fetchone()
    expense=c.execute("SELECT COALESCE(SUM(amount),0) v FROM expenses WHERE date(created_at) BETWEEN ? AND ?",(start,end)).fetchone()["v"]
    return render_template("reports.html",rows=rows,totals=totals,expense=expense,start=start,end=end)
if __name__=="__main__":
    init_db(); app.run(host="0.0.0.0",port=int(os.environ.get("PORT",5000)))
